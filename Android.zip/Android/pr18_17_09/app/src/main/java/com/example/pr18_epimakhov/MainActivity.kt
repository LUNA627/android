package com.example.pr18_epimakhov

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.Toast
import com.example.pr18_epimakhov.databinding.ActivityMainBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var button1: Button
    private lateinit var button2: Button
    private lateinit var button3: Button

    private lateinit var pref: SharedPreferences
    private var count = 0;
    private lateinit var fab: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pref = getPreferences(Context.MODE_PRIVATE)

        button1 = findViewById(R.id.button1)
        button2 = findViewById(R.id.button2)
        button3 = findViewById(R.id.button3)
        fab = findViewById(R.id.fab)


        count = pref.getInt("CLICK_COUNT", 0)
        // 1. Простой SnackBar
        button1.setOnClickListener { view ->
            Snackbar.make(view, "Программирование на Android", Snackbar.LENGTH_LONG).show()
        }


        // 2. SnackBar с действием
        button2.setOnClickListener { view ->
            Snackbar.make(view, "Вы изменили что-то", Snackbar.LENGTH_LONG)
                .setAction("Вернуть как было"){
                    Snackbar.make(view,"Все вернулось на свои места!", Snackbar.LENGTH_LONG).show()
                }
                .show()
        }



        // 3. Нестандартный SnackBar
        button3.setOnClickListener {view ->
            showRepeatSnackbar(view)
            incrementCoint(view)

        }
        fab.setOnClickListener { view ->
            Snackbar.make(view, "Вы нажали на FloatingActionButton", Snackbar.LENGTH_LONG).show()
        }
    }

    fun showRepeatSnackbar(view: View) {
        val snackbar = Snackbar.make(view, "Повторите еще раз!", Snackbar.LENGTH_LONG)
        snackbar.setAction("Повторить") {
            snackbar.dismiss()
            showRepeatSnackbar(view)
            incrementCoint(view)
        }
            snackbar.show()
    }

    fun incrementCoint(view: View){
        count++
        val editor = pref.edit()
        editor.putInt("CLICK_COUNT", 0)
        editor.apply()
        Toast.makeText(this, "Вы нажали $count раз", Toast.LENGTH_SHORT).show()
    }

}